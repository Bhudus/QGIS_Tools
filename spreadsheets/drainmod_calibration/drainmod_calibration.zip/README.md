# DRAINMOD Calibration

**Workbook:** `DRAINMOD_Calibration.xlsm` · Version 1.4 ·
[download zip](https://github.com/Bhudus/QGIS_Tools/raw/main/spreadsheets/drainmod_calibration/drainmod_calibration.zip)

Calibrates a DRAINMOD project to measured daily drain flow, water table depth or both,
by maximizing the Kling-Gupta efficiency (KGE). The search is Dynamically Dimensioned
Search (DDS, Tolson and Shoemaker 2007), with several DRAINMOD runs side by side and a
final local search ("polish") from the best values. A sensitivity analysis (Morris
elementary effects) ranks the parameters first, to help choose which ones to calibrate.

## Needs

* Windows Excel with macros enabled.
* DRAINMOD (`dmhydro.exe`, from
  [NC State University](https://bae.ncsu.edu/agricultural-water-management/drainmod/download/))
  and a DRAINMOD project (.prj with its .gen) with daily output turned on.
* Measured daily drain flow and/or water table depth.

## Use

On the **Setup** sheet:

1. Select the project (.prj) and `dmhydro.exe`. If the project folder was moved or
   copied, the runs use the paths of where it is now, and **Fix paths...** rewrites the
   paths in the project files themselves (keeping each original as .bak).
2. Paste the measured data on the **Measured** sheet: date, daily drain flow, daily water
   table depth (blank where not measured). Set the units, sign and what to calibrate to
   on the Setup sheet (drain flow in cm/day by default); KGE 2012 is the default, 2009
   can be chosen. Optionally, days when measured and simulated drain flow are both zero
   can be left out of the drain-flow statistics. The depth of the water table measuring
   instrument (100 cm by default) limits the water table statistics to days when the
   simulated depth is at or above it.
3. **1. Read project parameters** fills the current value of each parameter on the
   **Parameters** sheet and sets the calibration period to the simulation period.
4. On the Parameters sheet, give each parameter a minimum and maximum and set
   **Calibrate?** to Yes for those to fit. Parameters: lateral Ksat of each soil layer
   (or a multiplier for all layers), maximum surface storage, Kirkham depth, drainage
   coefficient, drain effective radius, vertical seepage K and piezometric head, PET
   multiplier, root depth multiplier, drain depth, depth to the impermeable layer,
   lateral seepage layer thickness, initial water table depth and drain spacing. The
   equivalent depth and Kirkham's G are recomputed whenever the drain geometry changes.
   The Kirkham depth for flow to drains is kept at or below the maximum surface storage
   in every run (with only one of the two calibrated, the project's value of the other is
   the limit), and a range that cannot meet this is reported before the runs start.
5. **2. Evaluate current values** runs DRAINMOD once and shows the fit on the
   **Results** sheet: the statistics, the daily values and charts of drain flow (with
   cumulative measured and simulated drain flow on a second axis) and water table depth.
6. **3. Sensitivity analysis** (optional) tests every parameter with a range that applies
   to the project, ticked or not. The **Sensitivity** sheet ranks them (1 = most
   sensitive) by mu\*, the mean absolute change in the objective when a parameter moves
   across its range, with sigma (non-linearity and interactions), the effect on the flow
   and water table KGE separately, and a bar chart; the ranks also go in the first column
   (Sensitivity rank) of the Parameters sheet. It takes trajectories × (parameters + 1) runs (10 trajectories by
   default, set on the Setup sheet).
7. **4. Run calibration** runs DDS and the polish. Each run is logged on the **Run Log**
   sheet; press Esc to stop early and keep the best values so far. Runs side by side are
   used only after a check that they reproduce a single run exactly, and a run longer
   than the time limit is stopped.
8. **5. Write calibrated project** asks for a name and saves the calibrated `.prj` and
   `.gen` with that name and the best values (the original project files cannot be
   overwritten).

Your project files are never changed by the runs: they write `<name>_cal.prj/.gen` (and
`_cal2`, `_cal3`, ... for runs side by side) next to them. The **Graphs** sheet charts
measured and simulated drain flow (with cumulative flow) and water table depth
(simulated depths below the measuring instrument are shown at its depth), and is
refreshed after each evaluation.

## Code

`vba/modCalib.bas` (all the macros) and `vba/ThisWorkbook.cls` (adds the buttons when the
workbook opens).

## Versions

* **1.4** – Write calibrated project asks for the name of the .prj and .gen; the
  Graphs sheet shows simulated water table depths below the measuring instrument at its
  depth.
* **1.3** – Water table depth chart on the Graphs sheet; depth of the water table
  measuring instrument (water table statistics use only days when the simulated depth is
  at or above it); Sensitivity rank moved to the first column of the Parameters sheet.
* **1.2** – Cumulative drain flow curves on a second axis of the Results drain flow
  chart; option to leave out days when measured and simulated drain flow are both zero;
  drain flow in cm/day and a depth to the impermeable layer of 120 to 250 cm by default.
* **1.1** – The Kirkham depth for flow to drains is kept at or below the maximum surface
  storage.
* **1** – First published version.

Copy dmhydro.exe and DMSOILP.EXE from your DRAINMOD installation into this folder.

DRAINMOD is free from NC State University:
https://bae.ncsu.edu/agricultural-water-management/drainmod/download/

Install it, then copy the two files from the folder DRAINMOD was installed in
(look for dmhydro.exe) to DDESIGN\Program.

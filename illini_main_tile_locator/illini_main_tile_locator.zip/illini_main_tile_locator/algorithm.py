"""Processing algorithm: locate a tile main for laterals parallel or perpendicular to the contours."""
import math
import os

import numpy as np
from qgis.core import (
    QgsCoordinateTransform,
    QgsFeature,
    QgsFeatureSink,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsLineString,
    QgsLineSymbol,
    QgsPoint,
    QgsPointXY,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingLayerPostProcessorInterface,
    QgsProcessingOutputNumber,
    QgsProcessingOutputString,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterDefinition,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterNumber,
    QgsProcessingParameterPoint,
    QgsProcessingParameterRasterLayer,
    QgsRectangle,
    QgsRuleBasedRenderer,
    QgsUnitTypes,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.PyQt.QtGui import QIcon

from .core import (
    ALIGN_BEST,
    ALIGN_STRAIGHT,
    ALIGN_TERRAIN,
    LAT_PARALLEL,
    LAT_PERPENDICULAR,
    SHAPE_AS_LOCATED,
    SHAPE_CONTOUR,
    SHAPE_SECTIONS,
    SHAPE_SMOOTHED,
    SHAPE_STRAIGHT,
    STATUS_LABELS,
    Grid,
    LocatorCancelled,
    LocatorError,
    LocatorParams,
    MANNING_N,
    lateral_capacity_length,
    run_locator,
)

PLUGIN_DIR = os.path.dirname(__file__)

ORIENTS = [LAT_PARALLEL, LAT_PERPENDICULAR]
SHAPES = [SHAPE_CONTOUR, SHAPE_STRAIGHT]
ALIGNS = [ALIGN_BEST, ALIGN_TERRAIN, ALIGN_STRAIGHT]
MAIN_SHAPES = [SHAPE_AS_LOCATED, SHAPE_SMOOTHED, SHAPE_SECTIONS]
Z_FACTORS = [1.0, 0.3048, 1200.0 / 3937.0]
UNIT_FACTORS = [1.0, 0.3048]
# keep post-processors alive until QGIS has used them
_POST = {}


def _meters_factor(crs):
    """Map units -> metres."""
    try:
        from qgis.core import Qgis
        return QgsUnitTypes.fromUnitToUnitFactor(crs.mapUnits(), Qgis.DistanceUnit.Meters)
    except (ImportError, AttributeError):
        return QgsUnitTypes.fromUnitToUnitFactor(crs.mapUnits(), QgsUnitTypes.DistanceMeters)


def _union_box(a, b):
    return QgsRectangle(min(a.xMinimum(), b.xMinimum()), min(a.yMinimum(), b.yMinimum()),
                        max(a.xMaximum(), b.xMaximum()), max(a.yMaximum(), b.yMaximum()))


def _advanced(param):
    try:
        from qgis.core import Qgis
        param.setFlags(param.flags() | Qgis.ProcessingParameterFlag.Advanced)
    except (ImportError, AttributeError):
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
    return param


def _label(layer, field):
    """Label each line with a field's value, along the line, in a white halo."""
    from qgis.core import (QgsPalLayerSettings, QgsTextBufferSettings, QgsTextFormat,
                           QgsVectorLayerSimpleLabeling)
    from qgis.PyQt.QtGui import QColor, QFont
    fmt = QgsTextFormat()
    font = QFont()
    font.setBold(True)
    fmt.setFont(font)
    fmt.setSize(10)
    fmt.setColor(QColor(30, 41, 59))
    buf = QgsTextBufferSettings()
    buf.setEnabled(True)
    buf.setSize(1.0)
    buf.setColor(QColor(255, 255, 255))
    fmt.setBuffer(buf)
    pal = QgsPalLayerSettings()
    pal.fieldName = field
    pal.isExpression = False
    pal.setFormat(fmt)
    try:
        from qgis.core import Qgis
        pal.placement = Qgis.LabelPlacement.Line
    except (ImportError, AttributeError):
        pal.placement = QgsPalLayerSettings.Line
    pal.enabled = True
    layer.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    layer.setLabelsEnabled(True)


class _SubmainStyler(QgsProcessingLayerPostProcessorInterface):
    """Submains orange, labelled with their name."""

    def postProcessLayer(self, layer, context, feedback):
        if not isinstance(layer, QgsVectorLayer):
            return
        root = QgsRuleBasedRenderer.Rule(None)
        ok = QgsLineSymbol.createSimple({"color": "234,88,12", "width": "0.8"})
        root.appendChild(QgsRuleBasedRenderer.Rule(
            ok, 0, 0, "\"flag\" IS NULL OR \"flag\" = ''", "Submain"))
        bad = QgsLineSymbol.createSimple({"color": "147,51,234", "width": "0.8"})
        root.appendChild(QgsRuleBasedRenderer.Rule(
            bad, 0, 0, "\"flag\" <> ''", "Submain to check (see flag)"))
        layer.setRenderer(QgsRuleBasedRenderer(root))
        try:
            _label(layer, "name")
        except Exception as e:  # noqa: BLE001
            feedback.pushWarning("Could not label the submains: {}".format(e))
        layer.triggerRepaint()


class _CandidateStyler(QgsProcessingLayerPostProcessorInterface):
    """Chosen main red; runners-up blue, dashed."""

    def postProcessLayer(self, layer, context, feedback):
        if not isinstance(layer, QgsVectorLayer):
            return
        root = QgsRuleBasedRenderer.Rule(None)
        ch = QgsLineSymbol.createSimple({"color": "185,28,28", "width": "1.2"})
        root.appendChild(QgsRuleBasedRenderer.Rule(ch, 0, 0, "\"chosen\"", "Chosen main"))
        run = QgsLineSymbol.createSimple({"color": "37,99,235", "width": "0.6",
                                          "line_style": "dash"})
        root.appendChild(QgsRuleBasedRenderer.Rule(run, 0, 0, "NOT \"chosen\"",
                                                   "Runner-up (see rank)"))
        layer.setRenderer(QgsRuleBasedRenderer(root))
        try:
            _label(layer, "rank")
        except Exception as e:  # noqa: BLE001  labels are a convenience only
            feedback.pushWarning("Could not label the candidates: {}".format(e))
        layer.triggerRepaint()


class MainTileLocatorAlgorithm(QgsProcessingAlgorithm):
    DEM = "DEM"
    FIELD = "FIELD"
    OUTLET = "OUTLET"
    ORIENTATION = "ORIENTATION"
    LATERAL_SHAPE = "LATERAL_SHAPE"
    ALIGNMENT = "ALIGNMENT"
    MAIN_SHAPE = "MAIN_SHAPE"
    SMOOTH_DIST = "SMOOTH_DIST"
    MIN_SECTION = "MIN_SECTION"
    UNITS = "UNITS"
    SPACING = "SPACING"
    MAX_LAT_MODE = "MAX_LAT_MODE"
    MAX_LAT_LEN = "MAX_LAT_LEN"
    INTENSITY = "INTENSITY"
    LAT_DIAMETER = "LAT_DIAMETER"
    LAT_SLOPE = "LAT_SLOPE"
    LAT_MATERIAL = "LAT_MATERIAL"
    MANNING = "MANNING"
    UPPER_DEPTH = "UPPER_DEPTH"
    LOWER_DEPTH = "LOWER_DEPTH"
    MIN_COVER = "MIN_COVER"
    MAX_DEPTH = "MAX_DEPTH"
    MAX_GRADE = "MAX_GRADE"
    MIN_MAIN_GRADE = "MIN_MAIN_GRADE"
    MIN_LAT_GRADE = "MIN_LAT_GRADE"
    OFFSET = "OFFSET"
    LOWER_OUTLET = "LOWER_OUTLET"
    OUTLET_INVERT = "OUTLET_INVERT"
    Z_UNITS = "Z_UNITS"
    CONTOUR_GRADE = "CONTOUR_GRADE"
    GRADE_BREAK = "GRADE_BREAK"
    BEARING_STEP = "BEARING_STEP"
    MAIN_STOP = "MAIN_STOP"
    MAIN_WEIGHT = "MAIN_WEIGHT"
    SETBACK = "SETBACK"
    SMOOTH = "SMOOTH"
    CELL_SIZE = "CELL_SIZE"
    CANDIDATES = "CANDIDATES"
    ADD_SUBMAINS = "ADD_SUBMAINS"
    MAX_SUBMAINS = "MAX_SUBMAINS"
    SUBMAINS = "SUBMAINS"
    PROFILE_MAIN = "PROFILE_MAIN"
    N_CANDIDATES = 5          # the chosen main and four runners-up

    # ------------------------------------------------------------ metadata
    def tr(self, s):
        return QCoreApplication.translate("MainTileLocator", s)

    def createInstance(self):
        return MainTileLocatorAlgorithm()

    def name(self):
        return "illinimaintilelocator"

    def displayName(self):
        return self.tr("Illini main tile locator")

    def group(self):
        return ""

    def groupId(self):
        return ""

    def icon(self):
        return QIcon(os.path.join(PLUGIN_DIR, "icon.png"))

    def shortHelpString(self):
        return self.tr(
            "<p>Locates a tile main from an <b>outlet</b>, a <b>DEM</b> and the <b>field "
            "boundary</b>, for laterals to be installed either <b>parallel</b> or "
            "<b>perpendicular</b> to the contour lines.</p>"
            "<p><b>How it works.</b> From every part of the field the tool traces the path a "
            "lateral would take: along the contours (either way, turned just enough downhill "
            "to hold the target lateral grade) or straight down the fall line, bending with "
            "the terrain or on one straight bearing. It then builds candidate mains from the "
            "outlet: the low-ground (thalweg) line, a fall-line trace, headers along the "
            "contours (with or without following the field edge), straight mains on every "
            "bearing, and dog-legs that run along the low side before turning up the slope. "
            "Each candidate is scored by the drainable area whose laterals reach it with "
            "enough fall, within the maximum lateral length and without converging into a "
            "draw, less a cost for its length and for any length that cannot be buried within "
            "the depth and slope limits. The best main is trimmed at its upper end while that "
            "helps, then buried with Routine J (Tile Burying System) of the Illini Drainage "
            "Tools.</p>"
            "<p><b>Laterals parallel to the contours</b> (across the slope) need a main that "
            "crosses the contours: up the slope, usually in the low ground. <b>Laterals "
            "perpendicular to the contours</b> (down the slope) need a main that runs along "
            "the contours across the low side of the field (a header), or up a draw they "
            "drain into.</p>"
            "<p><b>Outputs</b><br>"
            "<i>Candidate mains</i>: the chosen main (rank 1, <i>chosen</i> = true, drawn red) "
            "and the four runners-up (blue, dashed), each drawn from its upper end to the "
            "outlet, with the share of the drainable area its laterals reach, its length, "
            "design grade, depths and Routine J notes. Select the chosen one to use it as "
            "the <i>Main line(s)</i> input of the Illini Subsurface Drain Layout plugin "
            "(tick <i>Selected features only</i>).<br>"
            "<i>Submains</i> (only with <b>Add submains to cover the field</b>): after the "
            "main is chosen, the tool repeatedly finds the largest patches whose laterals "
            "still cannot drain to the network, tries submains into each (along the low "
            "ground, straight to the network, or as headers along the contours), and adds "
            "the one that drains the most extra area for its length, until no submain is "
            "worth adding. Each submain joins the main or an earlier submain, is buried with "
            "the main, and records the share of the field it adds (<i>gain_pct</i>). Ground "
            "below the outlet or beyond the maximum lateral length may still be left "
            "uncovered; the log reports how much.</p>"
            "<p><b>Shape of the chosen main.</b> If the chosen main is curved (it follows "
            "the low ground, the fall line or the contours), it can be <i>smoothed</i>, "
            "with a Gaussian along its length whose width is the smoothing distance, or "
            "turned into <i>straight sections</i>: the sections that follow the curve most "
            "closely with none shorter than the minimum section length. Both keep the outlet "
            "and the upper end where they are. The reshaped main is scored and buried again "
            "before any submains are added; mains made of straight lines are left as they "
            "are.</p>"
            "<p><b>Chosen main in straight sections (for Tile Profile)</b>: the chosen main "
            "as straight sections no shorter than the minimum section length (as it is, if it "
            "is already straight), buried with Routine J, and written like the Drainage "
            "network layer of Illini Subsurface Drain Layout so the Tile Profile plugin can "
            "read it: one line per stretch between junctions, linked by from_node and "
            "to_node, with the tile elevation as Z and the ground as M at every corner and "
            "grade break, and the fields pipe_id, kind, pipe, invert_us/ds, ground_us/ds, "
            "ElevDepth1/2, BuryDepth1/2, InSlope, OutSlope, BURY_CHECK and flag.</p>"
            "<p><b>Maximum lateral length.</b> By default it is the capacity of the lateral "
            "tile, from the maxLength routine (Table 6): the length a tile of the given inside "
            "diameter, slope and Manning's n can drain flowing full, for a strip one lateral "
            "spacing wide at the given drainage intensity. The defaults, a 4-inch corrugated "
            "plastic tube on a 0.1% slope at 3/8 in/day, give about 2,080 ft at 80 ft "
            "spacing. A fixed length or no limit can be chosen instead.</p>"
            "<p>All lengths, depths and elevations on this form and in the outputs are in the "
            "chosen design units; grades are in percent. The DEM must be in a projected "
            "CRS.</p>"
            "<p>Terrain handling and the Routine J burying scheme come from the Illini "
            "Subsurface Drain Layout plugin and the Illini Drainage Tools by Anamelechi "
            "Falasy and Richard Cooke, University of Illinois Urbana-Champaign (GPL v3).</p>")

    # ------------------------------------------------------------ parameters
    def initAlgorithm(self, config=None):
        D = QgsProcessingParameterNumber.Double
        self.addParameter(QgsProcessingParameterPoint(
            self.OUTLET, self.tr("Outlet location (click on the map)")))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.DEM, self.tr("Elevation (DEM)")))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.FIELD, self.tr("Field boundary"), [QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterEnum(
            self.ORIENTATION, self.tr("Laterals to be installed"),
            options=[self.tr("Parallel to the contour lines (across the slope)"),
                     self.tr("Perpendicular to the contour lines (down the slope)")],
            defaultValue=0))
        self.addParameter(QgsProcessingParameterEnum(
            self.LATERAL_SHAPE, self.tr("Lateral shape"),
            options=[self.tr("Bend with the terrain (follow the contours or fall line)"),
                     self.tr("Straight (dominant contour or fall bearing of the field)")],
            defaultValue=0))
        self.addParameter(QgsProcessingParameterEnum(
            self.ALIGNMENT, self.tr("Main alignment"),
            options=[self.tr("Best of all candidates"),
                     self.tr("Bend with the terrain only"),
                     self.tr("Straight lines only")],
            defaultValue=0))
        self.addParameter(QgsProcessingParameterEnum(
            self.MAIN_SHAPE, self.tr("Shape of the chosen main, if it is curved"),
            options=[self.tr("As located"),
                     self.tr("Smoothed"),
                     self.tr("Straight sections of a minimum length")],
            defaultValue=0))
        self.addParameter(QgsProcessingParameterNumber(
            self.SMOOTH_DIST, self.tr("Smoothing distance (when smoothed)"), D,
            defaultValue=200.0, minValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.MIN_SECTION,
            self.tr("Minimum section length (straight sections, and the main for Tile Profile)"),
            D,
            defaultValue=300.0, minValue=1.0))
        self.addParameter(QgsProcessingParameterBoolean(
            self.ADD_SUBMAINS,
            self.tr("Add submains to cover the field (to the chosen main)"),
            defaultValue=False))
        self.addParameter(QgsProcessingParameterEnum(
            self.UNITS, self.tr("Design units (spacing, lengths, depths, outputs)"),
            options=[self.tr("Metres"), self.tr("Feet")], defaultValue=1))
        self.addParameter(QgsProcessingParameterNumber(
            self.SPACING, self.tr("Lateral spacing"), D, defaultValue=80.0, minValue=1.0))
        self.addParameter(QgsProcessingParameterEnum(
            self.MAX_LAT_MODE, self.tr("Maximum lateral length"),
            options=[self.tr("Capacity of the lateral tile (maxLength routine)"),
                     self.tr("Fixed length (below)"),
                     self.tr("No limit")],
            defaultValue=0))
        self.addParameter(QgsProcessingParameterNumber(
            self.INTENSITY, self.tr("Lateral capacity: drainage intensity (inches per day)"),
            D, defaultValue=0.375, minValue=0.001))
        self.addParameter(QgsProcessingParameterNumber(
            self.LAT_DIAMETER, self.tr("Lateral capacity: inside diameter (inches)"), D,
            defaultValue=4.0, minValue=0.5))
        self.addParameter(QgsProcessingParameterNumber(
            self.LAT_SLOPE, self.tr("Lateral capacity: slope (%)"), D, defaultValue=0.1,
            minValue=0.001))
        self.addParameter(QgsProcessingParameterEnum(
            self.LAT_MATERIAL, self.tr("Lateral capacity: tile material"),
            options=[self.tr("Corrugated plastic tubing (n = 0.013)"),
                     self.tr("Clay or concrete tile (n = 0.012)")],
            defaultValue=0))
        self.addParameter(QgsProcessingParameterNumber(
            self.MANNING,
            self.tr("Lateral capacity: Manning's roughness coefficient [optional, overrides "
                    "the material]"), D, optional=True, minValue=0.001, maxValue=0.1))
        self.addParameter(QgsProcessingParameterNumber(
            self.MAX_LAT_LEN, self.tr("Fixed maximum lateral length"), D,
            defaultValue=1320.0, minValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.UPPER_DEPTH, self.tr("Burying: upper tile depth (target band)"), D,
            defaultValue=3.25, minValue=0.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.LOWER_DEPTH, self.tr("Burying: lower tile depth (target band)"), D,
            defaultValue=4.25, minValue=0.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.MIN_COVER, self.tr("Burying: absolute upper tile depth (minimum cover)"), D,
            defaultValue=2.5, minValue=0.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.MAX_DEPTH, self.tr("Burying: absolute lower tile depth (maximum depth)"), D,
            defaultValue=6.0, minValue=0.1))
        self.addParameter(QgsProcessingParameterNumber(
            self.MAX_GRADE, self.tr("Burying: maximum slope (%)"), D, defaultValue=5.0,
            minValue=0.01, maxValue=100.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.MIN_MAIN_GRADE, self.tr("Burying: minimum slope of the main (%)"), D,
            defaultValue=0.1, minValue=0.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.MIN_LAT_GRADE, self.tr("Minimum slope of the laterals (%)"), D,
            defaultValue=0.1, minValue=0.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.OFFSET, self.tr("Burying: offset depth at the outlet (+ lowers the outlet)"),
            D, defaultValue=0.0))
        self.addParameter(QgsProcessingParameterBoolean(
            self.LOWER_OUTLET,
            self.tr("Burying: lower the outlet for low ground (down to the lower tile depth)"),
            defaultValue=False))
        self.addParameter(QgsProcessingParameterNumber(
            self.OUTLET_INVERT,
            self.tr("Outlet invert elevation, in DEM elevation units [optional]"), D,
            optional=True))

        self.addParameter(_advanced(QgsProcessingParameterEnum(
            self.Z_UNITS, self.tr("DEM elevation units"),
            options=[self.tr("Metres"), self.tr("International feet"),
                     self.tr("US survey feet")], defaultValue=2)))
        self.addParameter(_advanced(QgsProcessingParameterNumber(
            self.CONTOUR_GRADE,
            self.tr("Target grade of laterals parallel to the contours (%)"), D,
            defaultValue=0.2, minValue=0.01)))
        self.addParameter(_advanced(QgsProcessingParameterNumber(
            self.GRADE_BREAK, self.tr("Burying: longest segment between grade breaks"), D,
            defaultValue=50.0, minValue=0.1)))
        self.addParameter(_advanced(QgsProcessingParameterNumber(
            self.BEARING_STEP, self.tr("Straight mains: bearing step (degrees)"), D,
            defaultValue=5.0, minValue=1.0, maxValue=45.0)))
        self.addParameter(_advanced(QgsProcessingParameterNumber(
            self.MAIN_STOP,
            self.tr("Low-ground main ends where its drainage area falls below (% of field)"),
            D, defaultValue=2.0, minValue=0.1, maxValue=50.0)))
        self.addParameter(_advanced(QgsProcessingParameterNumber(
            self.MAX_SUBMAINS, self.tr("Most submains to add"),
            QgsProcessingParameterNumber.Integer, defaultValue=20, minValue=1,
            maxValue=200)))
        self.addParameter(_advanced(QgsProcessingParameterNumber(
            self.MAIN_WEIGHT,
            self.tr("Scoring: cost of main length (drained strips of one spacing per unit "
                    "length)"), D, defaultValue=0.5, minValue=0.0, maxValue=10.0)))
        self.addParameter(_advanced(QgsProcessingParameterNumber(
            self.SETBACK, self.tr("Boundary setback [optional, default half the spacing]"), D,
            optional=True, minValue=0.0)))
        self.addParameter(_advanced(QgsProcessingParameterNumber(
            self.SMOOTH, self.tr("Terrain smoothing radius [optional, default the spacing]"),
            D, optional=True, minValue=0.0)))
        self.addParameter(_advanced(QgsProcessingParameterNumber(
            self.CELL_SIZE, self.tr("Analysis cell size [optional, automatic]"), D,
            optional=True, minValue=0.0)))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.CANDIDATES, self.tr("Candidate mains (chosen and four runners-up)"),
            QgsProcessing.TypeVectorLine))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.PROFILE_MAIN,
            self.tr("Chosen main in straight sections (for Tile Profile)"),
            QgsProcessing.TypeVectorLine, optional=True, createByDefault=True))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.SUBMAINS, self.tr("Submains (when added)"), QgsProcessing.TypeVectorLine,
            optional=True, createByDefault=True))

        for key, desc in (("MAIN_LENGTH", "Main length"),
                          ("SERVED_PCT", "Drainable area whose laterals reach the main (%)"),
                          ("OUTLET_DEPTH", "Outlet tile depth")):
            self.addOutput(QgsProcessingOutputNumber(key, self.tr(desc)))
        self.addOutput(QgsProcessingOutputString("METHOD", self.tr("Chosen candidate")))
        self.addOutput(QgsProcessingOutputString("WARNINGS", self.tr("Warnings")))

    # ------------------------------------------------------------ inputs
    @staticmethod
    def _rings(geom, xf):
        rings = []
        polys = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]
        for poly in polys:
            for ring in poly:
                if len(ring) >= 3:
                    rings.append(np.array([[p.x() * xf, p.y() * xf] for p in ring]))
        return rings

    @staticmethod
    def _read_dem(layer, bounds, nrows, ncols, feedback):
        """Resample the DEM onto the analysis grid (bilinear). Returns (array, valid)."""
        xmin, ymin, xmax, ymax = bounds
        if layer.providerType() == "gdal":
            try:
                from osgeo import gdal
                src = layer.dataProvider().dataSourceUri()
                tmp = "/vsimem/illini_main_tile_locator_dem.tif"
                ds = gdal.Warp(tmp, src, format="GTiff",
                               outputBounds=(xmin, ymin, xmax, ymax),
                               width=ncols, height=nrows, resampleAlg="bilinear",
                               dstNodata=-99999.0, outputType=gdal.GDT_Float32)
                arr = None
                if ds is not None:
                    arr = ds.GetRasterBand(1).ReadAsArray().astype(float)
                    ds = None
                gdal.Unlink(tmp)
                if arr is not None:
                    return arr, np.isfinite(arr) & (arr > -99998.0)
            except Exception as e:  # noqa: BLE001
                feedback.pushWarning("GDAL resampling failed ({}); falling back to "
                                     "nearest-neighbour reading.".format(e))
        block = layer.dataProvider().block(1, QgsRectangle(xmin, ymin, xmax, ymax),
                                           ncols, nrows)
        arr = np.empty((nrows, ncols))
        valid = np.ones((nrows, ncols), dtype=bool)
        for i in range(nrows):
            for j in range(ncols):
                arr[i, j] = block.value(i, j)
                if block.isNoData(i, j):
                    valid[i, j] = False
        return arr, valid & np.isfinite(arr)

    # ------------------------------------------------------------ run
    def processAlgorithm(self, parameters, context, feedback):
        dem_layer = self.parameterAsRasterLayer(parameters, self.DEM, context)
        if dem_layer is None:
            raise QgsProcessingException(self.tr("Could not load the DEM."))
        crs = dem_layer.crs()
        if not crs.isValid() or crs.isGeographic():
            raise QgsProcessingException(self.tr(
                "The DEM must be in a projected coordinate system (metres or feet). "
                "Reproject it with Raster > Projections > Warp first."))
        xf = _meters_factor(crs)
        uf = UNIT_FACTORS[self.parameterAsEnum(parameters, self.UNITS, context)]
        zf = Z_FACTORS[self.parameterAsEnum(parameters, self.Z_UNITS, context)]
        u_lbl = "m" if uf == 1.0 else "ft"

        def num(key, optional=False):
            if optional and parameters.get(key) in (None, ""):
                return None
            v = self.parameterAsDouble(parameters, key, context)
            if optional and (v is None or v != v):
                return None
            return v

        spacing = num(self.SPACING) * uf
        setback = num(self.SETBACK, True)
        smooth_r = num(self.SMOOTH, True)
        cell_in = num(self.CELL_SIZE, True)
        outlet_inv = num(self.OUTLET_INVERT, True)
        max_mode = self.parameterAsEnum(parameters, self.MAX_LAT_MODE, context)
        if max_mode == 0:
            n_man = num(self.MANNING, True)
            if n_man is None:
                n_man = MANNING_N["plastic" if self.parameterAsEnum(
                    parameters, self.LAT_MATERIAL, context) == 0 else "clay_concrete"]
            dia_in = num(self.LAT_DIAMETER)
            slope_pct = num(self.LAT_SLOPE)
            di_in = num(self.INTENSITY)
            try:
                max_lat_m = lateral_capacity_length(di_in * 0.0254, spacing, dia_in * 0.0254,
                                                    slope_pct / 100.0, n_man)
            except ValueError as e:
                raise QgsProcessingException(str(e))
            feedback.pushInfo(self.tr(
                "Maximum lateral length {:,.0f} {}: capacity of a {:g}-inch tile (n = {:g}) "
                "on a {:g}% slope at a drainage intensity of {:g} in/day and {:g} {} "
                "spacing.").format(max_lat_m / uf, u_lbl, dia_in, n_man, slope_pct, di_in,
                                   spacing / uf, u_lbl))
        elif max_mode == 1:
            max_lat_m = num(self.MAX_LAT_LEN) * uf
        else:
            max_lat_m = None

        source = self.parameterAsSource(parameters, self.FIELD, context)
        if source is None:
            raise QgsProcessingException(self.tr("Could not load the field boundary."))
        tr = QgsCoordinateTransform(source.sourceCrs(), crs, context.transformContext())
        geoms = []
        for f in source.getFeatures():
            g = QgsGeometry(f.geometry())
            if g.isEmpty():
                continue
            g.transform(tr)
            geoms.append(g)
        if not geoms:
            raise QgsProcessingException(self.tr("The field layer has no polygons."))
        field = QgsGeometry.unaryUnion(geoms) if len(geoms) > 1 else geoms[0]
        if len(geoms) > 1:
            feedback.pushInfo(self.tr("{} field polygons merged into one field.")
                              .format(len(geoms)))
        if parameters.get(self.OUTLET) in (None, ""):
            raise QgsProcessingException(self.tr("Pick the outlet location on the map."))
        outlet = self.parameterAsPoint(parameters, self.OUTLET, context, crs)

        # analysis grid
        bb = _union_box(field.boundingBox(),
                        QgsRectangle(outlet.x(), outlet.y(), outlet.x(), outlet.y()))
        area_m2 = field.area() * xf * xf
        dem_res_m = abs(dem_layer.rasterUnitsPerPixelX()) * xf
        if cell_in:
            cell_m = cell_in * uf
        else:
            cell_m = max(dem_res_m, spacing / 6.0, 0.5)
            cell_m = min(cell_m, spacing / 3.0)
            cell_m = max(cell_m, math.sqrt(area_m2 / 2.5e5))
            cell_m = round(cell_m, 2)
        smooth_m = smooth_r * uf if smooth_r is not None else spacing
        margin = (1.5 * smooth_m + 4 * cell_m) / xf
        cell_map = cell_m / xf
        xmin = math.floor((bb.xMinimum() - margin) / cell_map) * cell_map
        ymin = math.floor((bb.yMinimum() - margin) / cell_map) * cell_map
        xmax = math.ceil((bb.xMaximum() + margin) / cell_map) * cell_map
        ymax = math.ceil((bb.yMaximum() + margin) / cell_map) * cell_map
        ncols = int(round((xmax - xmin) / cell_map))
        nrows = int(round((ymax - ymin) / cell_map))
        if nrows * ncols > 6_000_000:
            raise QgsProcessingException(self.tr(
                "The analysis grid would have {:,} cells; set a larger analysis cell size."
            ).format(nrows * ncols))
        feedback.pushInfo(self.tr("Analysis grid: {} x {} cells of {:.2f} {}.")
                          .format(ncols, nrows, cell_m / uf, u_lbl))
        dem, valid = self._read_dem(dem_layer, (xmin, ymin, xmax, ymax), nrows, ncols,
                                    feedback)
        if not valid.any():
            raise QgsProcessingException(self.tr("The DEM has no data over the field."))
        dem = dem * zf
        grid = Grid(xmin * xf, ymax * xf, cell_m, nrows, ncols)

        params = LocatorParams(
            lateral_orientation=ORIENTS[self.parameterAsEnum(parameters, self.ORIENTATION,
                                                             context)],
            lateral_shape=SHAPES[self.parameterAsEnum(parameters, self.LATERAL_SHAPE, context)],
            alignment=ALIGNS[self.parameterAsEnum(parameters, self.ALIGNMENT, context)],
            spacing=spacing,
            max_lateral_length=max_lat_m,
            contour_grade=num(self.CONTOUR_GRADE) / 100.0,
            min_lateral_grade=num(self.MIN_LAT_GRADE) / 100.0,
            min_main_grade=num(self.MIN_MAIN_GRADE) / 100.0,
            max_grade=num(self.MAX_GRADE) / 100.0,
            target_upper=num(self.UPPER_DEPTH) * uf,
            target_lower=num(self.LOWER_DEPTH) * uf,
            min_cover=num(self.MIN_COVER) * uf,
            max_depth=num(self.MAX_DEPTH) * uf,
            outlet_offset=num(self.OFFSET) * uf,
            lower_outlet=self.parameterAsBool(parameters, self.LOWER_OUTLET, context),
            grade_break=num(self.GRADE_BREAK) * uf,
            outlet_invert=outlet_inv * zf if outlet_inv is not None else None,
            setback=setback * uf if setback is not None else None,
            smooth_radius=smooth_m,
            bearing_step=num(self.BEARING_STEP),
            main_weight=num(self.MAIN_WEIGHT),
            main_stop_frac=num(self.MAIN_STOP) / 100.0,
            main_shape=MAIN_SHAPES[self.parameterAsEnum(parameters, self.MAIN_SHAPE, context)],
            smooth_length=num(self.SMOOTH_DIST) * uf,
            min_section=num(self.MIN_SECTION) * uf,
            add_submains=self.parameterAsBool(parameters, self.ADD_SUBMAINS, context),
            max_submains=int(self.parameterAsInt(parameters, self.MAX_SUBMAINS, context)),
            units=u_lbl,
        )
        if params.target_lower < params.target_upper:
            raise QgsProcessingException(self.tr(
                "The lower tile depth must not be less than the upper tile depth."))
        if params.max_depth <= params.min_cover:
            raise QgsProcessingException(self.tr(
                "The absolute lower tile depth must be greater than the absolute upper "
                "tile depth."))

        def progress(pct, msg):
            feedback.setProgress(pct)
            feedback.setProgressText(msg)

        try:
            res = run_locator(dem, valid, grid, self._rings(field, xf),
                              (outlet.x() * xf, outlet.y() * xf), params,
                              progress=progress, cancel=feedback.isCanceled)
        except LocatorCancelled:
            return {}
        except LocatorError as e:
            raise QgsProcessingException(str(e))

        def pts_geom(coords):
            return [QgsPointXY(x / xf, y / xf) for x, y in coords]

        def fields(spec):
            fs = QgsFields()
            for name, typ in spec:
                fs.append(QgsField(name, typ))
            return fs

        Dv, Iv, Sv, Bv = QVariant.Double, QVariant.Int, QVariant.String, QVariant.Bool
        L = lambda v: round(v / uf, 3)          # noqa: E731  metres -> design units
        out = {}

        # ---------------------------------------------------- candidates
        cand_fields = fields([
            ("rank", Iv), ("chosen", Bv), ("name", Sv), ("method", Sv), ("arms", Iv),
            ("served_pct", Dv), ("length", Dv), ("problem_length", Dv),
            ("design_grade_pct", Dv), ("max_depth", Dv), ("min_depth", Dv),
            ("outlet_depth", Dv), ("BURY_CHECK", Sv), ("score", Dv)])
        csink, cand_id = self.parameterAsSink(parameters, self.CANDIDATES, context,
                                              cand_fields, QgsWkbTypes.MultiLineString, crs)
        if csink is None:
            raise QgsProcessingException(self.tr("Could not create the candidate layer."))
        for c in res["candidates"][:self.N_CANDIDATES]:
            a = c["attrs"]
            vals = {"rank": a["rank"], "chosen": bool(a["chosen"]), "name": a["name"],
                    "method": a["method"], "arms": a["arms"],
                    "served_pct": a["served_pct"], "length": L(a["length_m"]),
                    "problem_length": L(a["problem_m"]),
                    "design_grade_pct": a["design_grade_pct"],
                    "max_depth": L(a["max_depth_m"]), "min_depth": L(a["min_depth_m"]),
                    "outlet_depth": (L(a["outlet_depth_m"])
                                     if a["outlet_depth_m"] is not None else None),
                    "BURY_CHECK": a["bury_check"], "score": a["score"]}
            f = QgsFeature(cand_fields)
            f.setGeometry(QgsGeometry.fromMultiPolylineXY(
                [pts_geom(arm) for arm in c["coords"]]))
            f.setAttributes([vals[cand_fields.at(i).name()]
                             for i in range(cand_fields.count())])
            csink.addFeature(f, QgsFeatureSink.FastInsert)
        out[self.CANDIDATES] = cand_id
        if context.willLoadLayerOnCompletion(cand_id):
            _POST[cand_id] = _CandidateStyler()
            context.layerToLoadOnCompletionDetails(cand_id).setPostProcessor(_POST[cand_id])

        # ---------------------------------------------------- main for Tile Profile
        pm = res.get("profile_main")
        if parameters.get(self.PROFILE_MAIN) is not None and pm is None:
            feedback.pushWarning(self.tr("The straight-section main for Tile Profile could "
                                         "not be made."))
        elif parameters.get(self.PROFILE_MAIN) is not None:
            # the same fields as the Drainage network layer of Illini Subsurface Drain
            # Layout, which Tile Profile reads: tile elevation as Z and ground as M at
            # every vertex, in design units
            pm_fields = fields([
                ("id", Iv), ("pipe_id", Iv), ("kind", Sv), ("pipe", Sv), ("from_node", Iv),
                ("to_node", Iv), ("ds_link", Iv), ("length", Dv), ("sections", Iv),
                ("ground_us", Dv), ("ground_ds", Dv), ("terrain_grade_pct", Dv),
                ("invert_us", Dv), ("invert_ds", Dv), ("design_grade_pct", Dv),
                ("max_depth", Dv), ("min_depth", Dv), ("depth_ds", Dv),
                ("ElevDepth1", Dv), ("BuryDepth1", Dv), ("ElevDepth2", Dv), ("BuryDepth2", Dv),
                ("InSlope", Dv), ("OutSlope", Dv), ("BURY_CHECK", Sv), ("flag", Sv)])
            psink, pm_id = self.parameterAsSink(parameters, self.PROFILE_MAIN, context,
                                                pm_fields, QgsWkbTypes.LineStringZM, crs)
            if psink is not None:
                for ln in pm["lines"]:
                    a = ln["attrs"]
                    vals = {"id": a["id"], "pipe_id": a["pipe_id"], "kind": a["kind"],
                            "pipe": a["pipe"], "from_node": a["from_node"],
                            "to_node": a["to_node"], "ds_link": a["ds_link"],
                            "length": L(a["length_m"]), "sections": a["sections"],
                            "ground_us": L(a["ground_us"]), "ground_ds": L(a["ground_ds"]),
                            "terrain_grade_pct": a["terrain_grade_pct"],
                            "invert_us": L(a["invert_us"]), "invert_ds": L(a["invert_ds"]),
                            "design_grade_pct": a["design_grade_pct"],
                            "max_depth": L(a["max_depth_m"]), "min_depth": L(a["min_depth_m"]),
                            "depth_ds": L(a["depth_ds_m"]),
                            "ElevDepth1": L(a["invert_us"]),
                            "BuryDepth1": L(a["ground_us"] - a["invert_us"]),
                            "ElevDepth2": L(a["invert_ds"]),
                            "BuryDepth2": L(a["ground_ds"] - a["invert_ds"]),
                            "InSlope": a["in_slope"], "OutSlope": a["out_slope"],
                            "BURY_CHECK": a["bury_check"], "flag": a["flag"]}
                    f = QgsFeature(pm_fields)
                    f.setGeometry(QgsGeometry(QgsLineString([
                        QgsPoint(x / xf, y / xf, float(zt) / uf, float(gm) / uf)
                        for (x, y), zt, gm in zip(ln["coords"], ln["tile_z"],
                                                  ln["ground_m"])])))
                    f.setAttributes([vals[pm_fields.at(i).name()]
                                     for i in range(pm_fields.count())])
                    psink.addFeature(f, QgsFeatureSink.FastInsert)
                out[self.PROFILE_MAIN] = pm_id
                feedback.pushInfo(self.tr(
                    "Main for Tile Profile: {} straight sections, none shorter than {:g} {} "
                    "except the link to the outlet; {} line(s); its laterals reach {:.1f}% of "
                    "the drainable area.").format(
                    pm["sections"], params.min_section / uf, u_lbl, len(pm["lines"]),
                    pm["served_pct"]))

        # ---------------------------------------------------- submains
        if params.add_submains and parameters.get(self.SUBMAINS) is not None:
            sub_fields = fields([
                ("id", Iv), ("name", Sv), ("joins", Sv), ("method", Sv), ("length", Dv),
                ("ground_us", Dv), ("ground_ds", Dv), ("invert_us", Dv), ("invert_ds", Dv),
                ("design_grade_pct", Dv), ("max_depth", Dv), ("min_depth", Dv),
                ("gain_pct", Dv), ("BURY_CHECK", Sv), ("flag", Sv)])
            ssink, sub_id = self.parameterAsSink(parameters, self.SUBMAINS, context,
                                                 sub_fields, QgsWkbTypes.LineString, crs)
            if ssink is not None:
                for sm in res["submains"]:
                    a = sm["attrs"]
                    vals = {"id": a["sub_id"], "name": a["name"], "joins": a["joins"],
                            "method": a["method"], "length": L(a["length_m"]),
                            "ground_us": L(a["ground_us"]), "ground_ds": L(a["ground_ds"]),
                            "invert_us": L(a["invert_us"]), "invert_ds": L(a["invert_ds"]),
                            "design_grade_pct": a["design_grade_pct"],
                            "max_depth": L(a["max_depth_m"]),
                            "min_depth": L(a["min_depth_m"]), "gain_pct": a["gain_pct"],
                            "BURY_CHECK": a["bury_check"], "flag": a["flag"]}
                    f = QgsFeature(sub_fields)
                    f.setGeometry(QgsGeometry.fromPolylineXY(pts_geom(sm["coords"])))
                    f.setAttributes([vals[sub_fields.at(i).name()]
                                     for i in range(sub_fields.count())])
                    ssink.addFeature(f, QgsFeatureSink.FastInsert)
                out[self.SUBMAINS] = sub_id
                if context.willLoadLayerOnCompletion(sub_id):
                    _POST[sub_id] = _SubmainStyler()
                    context.layerToLoadOnCompletionDetails(sub_id).setPostProcessor(
                        _POST[sub_id])

        # ---------------------------------------------------- log
        s = res["summary"]
        feedback.pushInfo("")
        feedback.pushInfo(self.tr("Chosen main: {}").format(s["method"]))
        feedback.pushInfo(self.tr("Main length: {:,.0f} {}").format(
            s["main_length_m"] / uf, u_lbl))
        if params.add_submains:
            feedback.pushInfo(self.tr("Submains added: {} ({:,.0f} {}); the main alone "
                                      "serves {:.1f}%").format(
                s["submains"], s["submain_length_m"] / uf, u_lbl, s["main_served_pct"]))
        feedback.pushInfo(self.tr("Drainable area whose laterals reach the {}: {:.1f}% "
                                  "(converge first: {:.1f}%, do not reach: {:.1f}%, "
                                  "uphill: {:.1f}%)").format(
            "main and submains" if params.add_submains else "main", s["served_pct"], s["converge_pct"], s["noreach_pct"], s["uphill_pct"]))
        feedback.pushInfo(self.tr("Lateral run to the main: mean {:,.0f} {}, longest "
                                  "{:,.0f} {}").format(s["mean_lateral_run_m"] / uf, u_lbl,
                                                       s["longest_lateral_run_m"] / uf,
                                                       u_lbl))
        feedback.pushInfo(self.tr("Mean field slope {:.2f}%; contour bearing {:.0f} deg; "
                                  "downhill bearing {:.0f} deg; lateral bearing {:.0f} deg")
                          .format(s["mean_slope_pct"], s["contour_bearing_deg"],
                                  s["downhill_bearing_deg"], s["lateral_bearing_deg"]))
        if s.get("outlet_depth_m") is not None:
            feedback.pushInfo(self.tr("Outlet tile depth: {:.2f} {}").format(
                s["outlet_depth_m"] / uf, u_lbl))
        feedback.pushInfo(self.tr("{} candidate mains scored.").format(s["candidates"]))
        for w in res["warnings"]:
            feedback.pushWarning(w)

        out.update({
            "MAIN_LENGTH": s["main_length_m"] / uf,
            "SERVED_PCT": s["served_pct"],
            "OUTLET_DEPTH": (s["outlet_depth_m"] / uf
                             if s.get("outlet_depth_m") is not None else None),
            "METHOD": s["method"],
            "WARNINGS": "\n".join(res["warnings"]),
        })
        return out

    # ------------------------------------------------------------ outputs

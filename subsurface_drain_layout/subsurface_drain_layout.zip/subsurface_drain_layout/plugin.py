import os

from qgis.core import QgsApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

from .provider import DrainLayoutProvider

TILE_DRAINAGE_MENU = "&Tile Drainage"  # submenu shared by the QGIS_Tools drainage plugins

ALGORITHM_ID = "drainlayout:subsurfacedrainlayout"


class DrainLayoutPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.provider = None
        self.action = None

    def initProcessing(self):
        if self.provider is not None:
            return
        self.provider = DrainLayoutProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        self.initProcessing()
        icon = QIcon(os.path.join(os.path.dirname(__file__), "icon.png"))
        self.action = QAction(icon, "Subsurface drainage layout…", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&Subsurface Drainage", self.action)
        self.iface.addPluginToRasterMenu(TILE_DRAINAGE_MENU, self.action)
        self.iface.addToolBarIcon(self.action)
        try:
            from qgis.core import Qgis
            self.iface.messageBar().pushMessage(
                "Subsurface Drainage Layout",
                "This plugin is superseded by Illini Subsurface Drain Layout (Burying "
                "method: Minimum cover gives the same burying). It is no longer developed.",
                level=Qgis.Warning, duration=12)
        except Exception:  # noqa: BLE001
            pass

    def unload(self):
        if self.action is not None:
            self.iface.removePluginMenu("&Subsurface Drainage", self.action)
            self.iface.removePluginRasterMenu(TILE_DRAINAGE_MENU, self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None
        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None

    def run(self):
        import processing
        processing.execAlgorithmDialog(ALGORITHM_ID, {})
